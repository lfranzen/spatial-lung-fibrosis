## Test environments
* local Ubuntu 18.10  install, R 3.6.0
* win-builder (devel and release)
* rhub Windows Server 2008 R2 SP1, R-devel, 32/64 bit
* rhub Ubuntu Linux 16.04 LTS, R-release, GCC
* rhub Fedora Linux, R-devel, clang, gfortran 

## R CMD check results
There were no ERRORs or WARNINGs.

There was 1 NOTE:

* checking installed package size ... NOTE
  installed size is  6.7Mb
  sub-directories of 1Mb or more:
    doc    1.7Mb
    libs   4.7Mb


## Downstream dependencies
No Downstream dependencies known.
